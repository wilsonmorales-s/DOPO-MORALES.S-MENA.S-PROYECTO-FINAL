package domain;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

class HeadSoccerTest {

    private HeadSoccer iniciado() throws HeadSoccerException {
        HeadSoccer juego = new HeadSoccer();
        juego.iniciarPartido(new ConfiguracionPartido(TipoPartido.POR_GOLES, 3, "Ana", "Luis"));
        return juego;
    }

    @Test
    void alInicioNoHayPartido() {
        assertFalse(new HeadSoccer().hayPartido());
    }

    @Test
    void sinPartidoLasAccionesNoFallan() {
        HeadSoccer juego = new HeadSoccer();
        juego.actualizar(0.1);
        juego.moverJugador(Lado.IZQUIERDA, 1);
        juego.saltar(Lado.DERECHA);
        juego.patear(Lado.DERECHA);
        juego.pausar();
        juego.reanudar();
        juego.terminar();
        assertFalse(juego.hayPartido());
    }

    @Test
    void noIniciaConConfiguracionNula() {
        assertThrows(HeadSoccerException.class, () -> new HeadSoccer().iniciarPartido(null));
    }

    @Test
    void iniciarCreaElPartido() throws HeadSoccerException {
        assertTrue(iniciado().hayPartido());
    }

    @Test
    void moverJugadorCambiaSuPosicion() throws HeadSoccerException {
        HeadSoccer juego = iniciado();
        double x = juego.getPartido().getJugador(Lado.IZQUIERDA).getX();
        juego.moverJugador(Lado.IZQUIERDA, 1);
        juego.actualizar(0.1);
        assertTrue(juego.getPartido().getJugador(Lado.IZQUIERDA).getX() > x);
    }

    @Test
    void saltarYPatearActuanSobreElJugadorIndicado() throws HeadSoccerException {
        HeadSoccer juego = iniciado();
        juego.saltar(Lado.DERECHA);
        juego.patear(Lado.DERECHA);
        juego.actualizar(0.016);
        assertFalse(juego.getPartido().getJugador(Lado.DERECHA).estaEnSuelo());
        assertTrue(juego.getPartido().getJugador(Lado.DERECHA).estaPateando());
        assertTrue(juego.getPartido().getJugador(Lado.IZQUIERDA).estaEnSuelo());
    }

    @Test
    void pausarReanudarYTerminar() throws HeadSoccerException {
        HeadSoccer juego = iniciado();
        juego.pausar();
        assertEquals(EstadoPartido.PAUSADO, juego.getPartido().getEstado());
        juego.reanudar();
        assertEquals(EstadoPartido.EN_JUEGO, juego.getPartido().getEstado());
        juego.terminar();
        assertEquals(EstadoPartido.FINALIZADO, juego.getPartido().getEstado());
    }
}
