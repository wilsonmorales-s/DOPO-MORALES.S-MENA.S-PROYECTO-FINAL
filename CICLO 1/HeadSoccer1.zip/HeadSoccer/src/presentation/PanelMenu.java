package presentation;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

/** Menu principal. */
public class PanelMenu extends JPanel {

    private static final String AYUDA = """
            Jugador 1 (izquierda)
              A / D mover      W saltar      S patear

            Jugador 2 (derecha)
              Flechas izquierda / derecha mover
              Flecha arriba saltar      Flecha abajo patear

            Durante el partido
              ESC o P pausa      T terminar      M volver al menu
              R o Enter revancha (al terminar)
            """;

    public PanelMenu(HeadSoccerGUI ventana) {
        setBackground(Tema.FONDO);
        setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.gridx = 0;
        c.insets = new Insets(10, 0, 10, 0);
        c.fill = GridBagConstraints.HORIZONTAL;

        JLabel titulo = new JLabel("HEAD SOCCER", SwingConstants.CENTER);
        titulo.setFont(Tema.TITULO);
        titulo.setForeground(Tema.ACENTO);
        c.insets = new Insets(0, 0, 40, 0);
        add(titulo, c);

        c.insets = new Insets(10, 0, 10, 0);
        add(boton("JUGAR", e -> ventana.mostrarConfiguracion()), c);
        add(boton("CONTROLES", e -> JOptionPane.showMessageDialog(this, AYUDA, "Controles",
                JOptionPane.PLAIN_MESSAGE)), c);
        add(boton("SALIR", e -> System.exit(0)), c);
    }

    private JButton boton(String texto, java.awt.event.ActionListener accion) {
        JButton b = new JButton(texto);
        b.setFont(Tema.BOTON);
        b.setFocusPainted(false);
        b.setPreferredSize(new java.awt.Dimension(260, 50));
        b.addActionListener(accion);
        return b;
    }
}
