package presentation;

import domain.ConfiguracionPartido;
import domain.HeadSoccer;
import domain.HeadSoccerException;
import java.awt.CardLayout;
import java.awt.Dimension;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

/** Ventana principal: cambia entre menu, configuracion y juego. */
public class HeadSoccerGUI extends JFrame {

    private static final String MENU = "menu";
    private static final String CONFIGURACION = "configuracion";
    private static final String JUEGO = "juego";

    private final HeadSoccer juego = new HeadSoccer();
    private final CardLayout cartas = new CardLayout();
    private final JPanel contenedor = new JPanel(cartas);
    private final PanelJuego panelJuego = new PanelJuego(this, juego);

    public HeadSoccerGUI() {
        super("Head Soccer");
        contenedor.add(new PanelMenu(this), MENU);
        contenedor.add(new PanelConfiguracion(this), CONFIGURACION);
        contenedor.add(panelJuego, JUEGO);
        add(contenedor);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setMinimumSize(new Dimension(800, 520));
        setSize(1100, 700);
        setLocationRelativeTo(null);
    }

    public void mostrarMenu() {
        panelJuego.detener();
        cartas.show(contenedor, MENU);
    }

    public void mostrarConfiguracion() {
        cartas.show(contenedor, CONFIGURACION);
    }

    /** Crea el partido en el dominio y muestra la pantalla de juego. */
    public void comenzar(ConfiguracionPartido configuracion) throws HeadSoccerException {
        juego.iniciarPartido(configuracion);
        cartas.show(contenedor, JUEGO);
        panelJuego.iniciar();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new HeadSoccerGUI().setVisible(true));
    }
}
