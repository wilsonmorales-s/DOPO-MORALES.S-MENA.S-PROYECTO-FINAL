package presentation;

import domain.Balon;
import domain.Campo;
import domain.EstadoPartido;
import domain.HeadSoccer;
import domain.HeadSoccerException;
import domain.Jugador;
import domain.Lado;
import domain.Partido;
import domain.TipoPartido;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.HashSet;
import java.util.Set;
import javax.swing.JPanel;
import javax.swing.Timer;

/** Dibuja el partido y lee el teclado. La logica del juego esta en el dominio. */
public class PanelJuego extends JPanel implements KeyListener {

    private static final int ALTO_MARCADOR = 80;
    private static final int ALTO_PASTO = 40;

    private final HeadSoccerGUI ventana;
    private final HeadSoccer juego;
    private final Timer reloj;
    private final Set<Integer> teclas = new HashSet<>();
    private long ultimo;

    public PanelJuego(HeadSoccerGUI ventana, HeadSoccer juego) {
        this.ventana = ventana;
        this.juego = juego;
        this.reloj = new Timer(16, e -> paso());
        setFocusable(true);
        addKeyListener(this);
    }

    public void iniciar() {
        teclas.clear();
        ultimo = System.nanoTime();
        reloj.start();
        requestFocusInWindow();
    }

    public void detener() {
        reloj.stop();
    }

    private void paso() {
        long ahora = System.nanoTime();
        double dt = Math.min((ahora - ultimo) / 1e9, 0.05);
        ultimo = ahora;
        juego.moverJugador(Lado.IZQUIERDA, direccion(KeyEvent.VK_A, KeyEvent.VK_D));
        juego.moverJugador(Lado.DERECHA, direccion(KeyEvent.VK_LEFT, KeyEvent.VK_RIGHT));
        juego.actualizar(dt);
        repaint();
    }

    private int direccion(int izquierda, int derecha) {
        int d = 0;
        if (teclas.contains(izquierda)) d--;
        if (teclas.contains(derecha)) d++;
        return d;
    }

    // ---------------------------------------------------------------- teclado

    @Override
    public void keyPressed(KeyEvent e) {
        int codigo = e.getKeyCode();
        if (!teclas.add(codigo)) {
            return;
        }
        Partido p = juego.getPartido();
        switch (codigo) {
            case KeyEvent.VK_W -> juego.saltar(Lado.IZQUIERDA);
            case KeyEvent.VK_S -> juego.patear(Lado.IZQUIERDA);
            case KeyEvent.VK_UP -> juego.saltar(Lado.DERECHA);
            case KeyEvent.VK_DOWN -> juego.patear(Lado.DERECHA);
            case KeyEvent.VK_ESCAPE, KeyEvent.VK_P -> alternarPausa(p);
            case KeyEvent.VK_T -> juego.terminar();
            case KeyEvent.VK_M -> ventana.mostrarMenu();
            case KeyEvent.VK_R, KeyEvent.VK_ENTER -> {
                if (p != null && p.getEstado() == EstadoPartido.FINALIZADO) {
                    revancha(p);
                }
            }
            default -> { }
        }
    }

    private void alternarPausa(Partido p) {
        if (p == null) {
            return;
        }
        if (p.getEstado() == EstadoPartido.EN_JUEGO) {
            juego.pausar();
        } else if (p.getEstado() == EstadoPartido.PAUSADO) {
            juego.reanudar();
        }
    }

    private void revancha(Partido p) {
        try {
            ventana.comenzar(p.getConfiguracion());
        } catch (HeadSoccerException ex) {
            ventana.mostrarMenu();
        }
    }

    @Override
    public void keyReleased(KeyEvent e) {
        teclas.remove(e.getKeyCode());
    }

    @Override
    public void keyTyped(KeyEvent e) {
    }

    // ---------------------------------------------------------------- dibujo

    @Override
    protected void paintComponent(Graphics g0) {
        super.paintComponent(g0);
        Partido p = juego.getPartido();
        if (p == null) {
            return;
        }
        Graphics2D g = (Graphics2D) g0.create();
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);

        Campo campo = p.getCampo();
        int w = getWidth();
        int h = getHeight();
        double mundoAncho = campo.getAncho() + 2 * campo.getAnchoPorteria();
        double espacioAlto = h - ALTO_MARCADOR - ALTO_PASTO;
        double escala = Math.min(w / mundoAncho, espacioAlto / campo.getAlto());
        double ox = (w - mundoAncho * escala) / 2 + campo.getAnchoPorteria() * escala;
        double arriba = ALTO_MARCADOR + (espacioAlto - campo.getAlto() * escala) / 2;
        double suelo = arriba + campo.getAlto() * escala;

        g.setPaint(new GradientPaint(0, 0, Tema.CIELO_ARRIBA, 0, (float) suelo, Tema.CIELO_ABAJO));
        g.fillRect(0, 0, w, (int) suelo);
        g.setColor(Tema.PASTO);
        g.fillRect(0, (int) suelo, w, h - (int) suelo);
        g.setColor(Tema.PASTO_OSCURO);
        g.fillRect(0, (int) suelo, w, 6);

        dibujarPorteria(g, campo, ox, suelo, escala, true);
        dibujarPorteria(g, campo, ox, suelo, escala, false);
        dibujarJugador(g, p.getJugador(Lado.IZQUIERDA), Tema.JUGADOR_IZQUIERDO, ox, suelo, escala);
        dibujarJugador(g, p.getJugador(Lado.DERECHA), Tema.JUGADOR_DERECHO, ox, suelo, escala);
        dibujarBalon(g, p.getBalon(), ox, suelo, escala);
        dibujarMarcador(g, p, w);
        dibujarMensaje(g, p, w, h);
        g.dispose();
    }

    private void dibujarPorteria(Graphics2D g, Campo campo, double ox, double suelo, double escala,
            boolean izquierda) {
        double ancho = campo.getAnchoPorteria() * escala;
        double alto = campo.getAltoPorteria() * escala;
        double x = izquierda ? ox - ancho : ox + campo.getAncho() * escala;
        g.setColor(new Color(255, 255, 255, 70));
        g.fillRect((int) x, (int) (suelo - alto), (int) ancho, (int) alto);
        g.setColor(new Color(255, 255, 255, 120));
        for (int i = 1; i < 6; i++) {
            int yy = (int) (suelo - alto + alto * i / 6);
            g.drawLine((int) x, yy, (int) (x + ancho), yy);
        }
        g.setStroke(new BasicStroke(5));
        g.setColor(Color.WHITE);
        g.drawLine((int) x, (int) (suelo - alto), (int) (x + ancho), (int) (suelo - alto));
        int poste = izquierda ? (int) (x + ancho) : (int) x;
        g.drawLine(poste, (int) (suelo - alto), poste, (int) suelo);
    }

    private void dibujarJugador(Graphics2D g, Jugador j, Color color, double ox, double suelo, double escala) {
        double r = Jugador.RADIO * escala;
        double cx = ox + j.getCentroX() * escala;
        double cy = suelo - j.getCentroY() * escala;
        g.setColor(new Color(0, 0, 0, 50));
        g.fillOval((int) (cx - r * 0.8), (int) (suelo - 5), (int) (r * 1.6), 10);
        g.setColor(color);
        g.fillOval((int) (cx - r), (int) (cy - r), (int) (2 * r), (int) (2 * r));
        g.setStroke(new BasicStroke(3));
        g.setColor(color.darker().darker());
        g.drawOval((int) (cx - r), (int) (cy - r), (int) (2 * r), (int) (2 * r));

        int sentido = j.getLado() == Lado.IZQUIERDA ? 1 : -1;
        double ojoX = cx + sentido * r * 0.35;
        g.setColor(Color.WHITE);
        g.fillOval((int) (ojoX - r * 0.25), (int) (cy - r * 0.4), (int) (r * 0.5), (int) (r * 0.5));
        g.setColor(Color.BLACK);
        g.fillOval((int) (ojoX + sentido * r * 0.05 - r * 0.1), (int) (cy - r * 0.25),
                (int) (r * 0.2), (int) (r * 0.2));

        if (j.estaPateando()) {
            g.setColor(Color.DARK_GRAY);
            double pie = sentido * (r + 22 * escala);
            g.fillOval((int) (cx + pie - 16 * escala), (int) (cy + r * 0.6), (int) (32 * escala), (int) (18 * escala));
        }
    }

    private void dibujarBalon(Graphics2D g, Balon b, double ox, double suelo, double escala) {
        double r = Balon.RADIO * escala;
        double cx = ox + b.getX() * escala;
        double cy = suelo - b.getY() * escala;
        g.setColor(Color.WHITE);
        g.fillOval((int) (cx - r), (int) (cy - r), (int) (2 * r), (int) (2 * r));
        g.setColor(Color.BLACK);
        g.setStroke(new BasicStroke(2));
        g.drawOval((int) (cx - r), (int) (cy - r), (int) (2 * r), (int) (2 * r));
        g.fillOval((int) (cx - r * 0.3), (int) (cy - r * 0.3), (int) (r * 0.6), (int) (r * 0.6));
    }

    private void dibujarMarcador(Graphics2D g, Partido p, int w) {
        g.setColor(Tema.FONDO);
        g.fillRect(0, 0, w, ALTO_MARCADOR);
        int izq = p.getMarcador().getGoles(Lado.IZQUIERDA);
        int der = p.getMarcador().getGoles(Lado.DERECHA);

        g.setFont(Tema.SUBTITULO);
        g.setColor(Tema.JUGADOR_IZQUIERDO);
        g.drawString(p.getJugador(Lado.IZQUIERDA).getNombre(), 20, 35);
        g.setColor(Tema.JUGADOR_DERECHO);
        String nombreDer = p.getJugador(Lado.DERECHA).getNombre();
        g.drawString(nombreDer, w - 20 - g.getFontMetrics().stringWidth(nombreDer), 35);

        g.setColor(Tema.TEXTO);
        g.setFont(new Font("SansSerif", Font.BOLD, 40));
        centrado(g, izq + "  -  " + der, w / 2, 40);

        g.setFont(Tema.NORMAL);
        g.setColor(Tema.ACENTO);
        String info;
        if (p.getConfiguracion().getTipo() == TipoPartido.POR_TIEMPO) {
            int t = (int) Math.ceil(p.getTiempoRestante());
            info = p.enMuerteSubita() ? "MUERTE SUBITA" : String.format("%d:%02d", t / 60, t % 60);
        } else {
            info = "Primero a " + p.getConfiguracion().getLimite() + " goles";
        }
        centrado(g, info, w / 2, 68);
    }

    private void dibujarMensaje(Graphics2D g, Partido p, int w, int h) {
        String titulo;
        String ayuda;
        if (p.getEstado() == EstadoPartido.PAUSADO) {
            titulo = "PAUSA";
            ayuda = "ESC o P para continuar   |   M menu";
        } else if (p.getEstado() == EstadoPartido.FINALIZADO) {
            Jugador ganador = p.getGanador();
            titulo = ganador == null ? "EMPATE" : "GANA " + ganador.getNombre().toUpperCase();
            ayuda = "R o Enter revancha   |   M menu";
        } else {
            return;
        }
        g.setColor(new Color(0, 0, 0, 150));
        g.fillRect(0, ALTO_MARCADOR, w, h - ALTO_MARCADOR);
        g.setColor(Tema.ACENTO);
        g.setFont(new Font("SansSerif", Font.BOLD, 56));
        centrado(g, titulo, w / 2, h / 2);
        g.setColor(Tema.TEXTO);
        g.setFont(Tema.SUBTITULO);
        centrado(g, ayuda, w / 2, h / 2 + 50);
    }

    private void centrado(Graphics2D g, String texto, int x, int y) {
        FontMetrics fm = g.getFontMetrics();
        g.drawString(texto, x - fm.stringWidth(texto) / 2, y);
    }
}
