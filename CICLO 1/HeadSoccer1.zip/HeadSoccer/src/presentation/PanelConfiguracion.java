package presentation;

import domain.ConfiguracionPartido;
import domain.HeadSoccerException;
import domain.TipoPartido;
import java.awt.Color;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JSpinner;
import javax.swing.JTextField;
import javax.swing.SpinnerNumberModel;
import javax.swing.SwingConstants;

/** Pantalla donde se configura el partido antes de jugar. */
public class PanelConfiguracion extends JPanel {

    private final HeadSoccerGUI ventana;
    private final JRadioButton porTiempo = new JRadioButton("Por tiempo", true);
    private final JRadioButton porGoles = new JRadioButton("Por goles");
    private final JSpinner limite = new JSpinner(new SpinnerNumberModel(3, 1, 99, 1));
    private final JLabel etiquetaLimite = new JLabel("Minutos:");
    private final JTextField nombre1 = new JTextField("Jugador 1", 14);
    private final JTextField nombre2 = new JTextField("Jugador 2", 14);
    private final JLabel error = new JLabel(" ", SwingConstants.CENTER);

    public PanelConfiguracion(HeadSoccerGUI ventana) {
        this.ventana = ventana;
        setBackground(Tema.FONDO);
        setLayout(new GridBagLayout());

        ButtonGroup grupo = new ButtonGroup();
        grupo.add(porTiempo);
        grupo.add(porGoles);
        for (JRadioButton r : new JRadioButton[] {porTiempo, porGoles}) {
            r.setOpaque(false);
            r.setForeground(Tema.TEXTO);
            r.setFont(Tema.NORMAL);
        }
        porTiempo.addActionListener(e -> etiquetaLimite.setText("Minutos:"));
        porGoles.addActionListener(e -> etiquetaLimite.setText("Goles:"));

        error.setForeground(new Color(255, 138, 128));
        error.setFont(Tema.NORMAL);

        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(8, 10, 8, 10);
        c.fill = GridBagConstraints.HORIZONTAL;

        c.gridx = 0; c.gridy = 0; c.gridwidth = 2;
        JLabel titulo = new JLabel("CONFIGURAR PARTIDO", SwingConstants.CENTER);
        titulo.setFont(Tema.SUBTITULO);
        titulo.setForeground(Tema.ACENTO);
        add(titulo, c);

        c.gridwidth = 1;
        c.gridy = 1; c.gridx = 0; add(etiqueta("Tipo de partido:"), c);
        JPanel tipos = new JPanel();
        tipos.setOpaque(false);
        tipos.add(porTiempo);
        tipos.add(porGoles);
        c.gridx = 1; add(tipos, c);

        c.gridy = 2; c.gridx = 0; add(etiquetaLimite, c);
        etiquetaLimite.setForeground(Tema.TEXTO);
        etiquetaLimite.setFont(Tema.NORMAL);
        c.gridx = 1; add(limite, c);

        c.gridy = 3; c.gridx = 0; add(etiqueta("Jugador 1 (izquierda):"), c);
        c.gridx = 1; add(nombre1, c);

        c.gridy = 4; c.gridx = 0; add(etiqueta("Jugador 2 (derecha):"), c);
        c.gridx = 1; add(nombre2, c);

        c.gridy = 5; c.gridx = 0; c.gridwidth = 2;
        add(error, c);

        JPanel botones = new JPanel();
        botones.setOpaque(false);
        JButton volver = new JButton("VOLVER");
        JButton comenzar = new JButton("COMENZAR");
        for (JButton b : new JButton[] {volver, comenzar}) {
            b.setFont(Tema.BOTON);
            b.setFocusPainted(false);
            botones.add(b);
        }
        volver.addActionListener(e -> ventana.mostrarMenu());
        comenzar.addActionListener(e -> comenzar());
        c.gridy = 6;
        add(botones, c);
    }

    private JLabel etiqueta(String texto) {
        JLabel l = new JLabel(texto);
        l.setForeground(Tema.TEXTO);
        l.setFont(Tema.NORMAL);
        return l;
    }

    private void comenzar() {
        try {
            TipoPartido tipo = porTiempo.isSelected() ? TipoPartido.POR_TIEMPO : TipoPartido.POR_GOLES;
            ConfiguracionPartido config = new ConfiguracionPartido(tipo, (Integer) limite.getValue(),
                    nombre1.getText(), nombre2.getText());
            error.setText(" ");
            ventana.comenzar(config);
        } catch (HeadSoccerException ex) {
            error.setText(ex.getMessage());
        }
    }
}
