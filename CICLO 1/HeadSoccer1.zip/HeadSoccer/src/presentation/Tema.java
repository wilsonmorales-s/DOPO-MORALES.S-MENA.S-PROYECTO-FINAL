package presentation;

import java.awt.Color;
import java.awt.Font;

/** Colores y fuentes compartidos por los paneles. */
final class Tema {

    static final Color FONDO = new Color(18, 32, 58);
    static final Color CIELO_ARRIBA = new Color(70, 140, 215);
    static final Color CIELO_ABAJO = new Color(170, 215, 245);
    static final Color PASTO = new Color(46, 125, 50);
    static final Color PASTO_OSCURO = new Color(36, 100, 40);
    static final Color JUGADOR_IZQUIERDO = new Color(33, 150, 243);
    static final Color JUGADOR_DERECHO = new Color(229, 57, 53);
    static final Color TEXTO = Color.WHITE;
    static final Color ACENTO = new Color(255, 193, 7);

    static final Font TITULO = new Font("SansSerif", Font.BOLD, 48);
    static final Font SUBTITULO = new Font("SansSerif", Font.BOLD, 22);
    static final Font NORMAL = new Font("SansSerif", Font.PLAIN, 16);
    static final Font BOTON = new Font("SansSerif", Font.BOLD, 20);

    private Tema() {
    }
}
