package domain;

/** Lado de la cancha que ocupa un jugador. */
public enum Lado {
    IZQUIERDA, DERECHA;

    public Lado opuesto() {
        return this == IZQUIERDA ? DERECHA : IZQUIERDA;
    }
}
