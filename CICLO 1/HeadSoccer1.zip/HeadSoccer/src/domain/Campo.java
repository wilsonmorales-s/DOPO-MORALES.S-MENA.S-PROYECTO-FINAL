package domain;

/** Cancha: dimensiones y porterias. El suelo esta en y = 0 y la altura crece hacia arriba. */
public class Campo {

    public static final double ANCHO = 1000;
    public static final double ALTO = 500;
    public static final double ALTO_PORTERIA = 170;
    public static final double ANCHO_PORTERIA = 70;

    private final double ancho;
    private final double alto;
    private final double altoPorteria;
    private final double anchoPorteria;

    public Campo() {
        this.ancho = ANCHO;
        this.alto = ALTO;
        this.altoPorteria = ALTO_PORTERIA;
        this.anchoPorteria = ANCHO_PORTERIA;
    }

    public double getAncho() { return ancho; }
    public double getAlto() { return alto; }
    public double getAltoPorteria() { return altoPorteria; }
    public double getAnchoPorteria() { return anchoPorteria; }

    /** Indica si un balon de ese radio, a esa altura, cabe por la boca de la porteria. */
    public boolean cabeEnPorteria(double alturaCentro, double radio) {
        return alturaCentro + radio <= altoPorteria;
    }
}
