package domain;

/** Estados por los que pasa un partido. */
public enum EstadoPartido {
    EN_JUEGO, PAUSADO, FINALIZADO
}
