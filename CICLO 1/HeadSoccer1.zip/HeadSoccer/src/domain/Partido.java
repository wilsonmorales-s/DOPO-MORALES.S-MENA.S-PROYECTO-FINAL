package domain;

/** Reglas y simulacion de un partido Jugador vs Jugador. */
public class Partido {

    private static final double COEF_REBOTE_JUGADOR = 0.8;

    private final ConfiguracionPartido configuracion;
    private final Campo campo;
    private final Balon balon;
    private final Jugador jugadorIzquierdo;
    private final Jugador jugadorDerecho;
    private final Marcador marcador;
    private EstadoPartido estado;
    private double tiempoRestante;
    private boolean muerteSubita;

    public Partido(ConfiguracionPartido configuracion) {
        this.configuracion = configuracion;
        this.campo = new Campo();
        this.marcador = new Marcador();
        this.jugadorIzquierdo = new Jugador(configuracion.getNombreIzquierdo(), Lado.IZQUIERDA, xInicial(Lado.IZQUIERDA));
        this.jugadorDerecho = new Jugador(configuracion.getNombreDerecho(), Lado.DERECHA, xInicial(Lado.DERECHA));
        this.balon = new Balon(campo.getAncho() / 2, campo.getAlto() / 2);
        this.estado = EstadoPartido.EN_JUEGO;
        if (configuracion.getTipo() == TipoPartido.POR_TIEMPO) {
            this.tiempoRestante = configuracion.getLimite() * 60.0;
        }
    }

    public ConfiguracionPartido getConfiguracion() { return configuracion; }
    public Campo getCampo() { return campo; }
    public Balon getBalon() { return balon; }
    public Marcador getMarcador() { return marcador; }
    public EstadoPartido getEstado() { return estado; }
    public double getTiempoRestante() { return tiempoRestante; }
    public boolean enMuerteSubita() { return muerteSubita; }

    public Jugador getJugador(Lado lado) {
        return lado == Lado.IZQUIERDA ? jugadorIzquierdo : jugadorDerecho;
    }

    /** Jugador con mas goles; null si el partido no ha terminado o quedo empatado. */
    public Jugador getGanador() {
        if (estado != EstadoPartido.FINALIZADO) {
            return null;
        }
        int izq = marcador.getGoles(Lado.IZQUIERDA);
        int der = marcador.getGoles(Lado.DERECHA);
        if (izq == der) {
            return null;
        }
        return izq > der ? jugadorIzquierdo : jugadorDerecho;
    }

    public void pausar() {
        if (estado == EstadoPartido.EN_JUEGO) {
            estado = EstadoPartido.PAUSADO;
        }
    }

    public void reanudar() {
        if (estado == EstadoPartido.PAUSADO) {
            estado = EstadoPartido.EN_JUEGO;
        }
    }

    public void terminar() {
        estado = EstadoPartido.FINALIZADO;
    }

    /** Avanza dt segundos de juego. No hace nada si el partido no esta en juego. */
    public void actualizar(double dt) {
        if (estado != EstadoPartido.EN_JUEGO) {
            return;
        }
        jugadorIzquierdo.actualizar(dt, campo);
        jugadorDerecho.actualizar(dt, campo);
        resolverContacto(jugadorIzquierdo);
        resolverContacto(jugadorDerecho);
        balon.actualizar(dt, campo);
        verificarGol();
        if (estado == EstadoPartido.EN_JUEGO) {
            avanzarTiempo(dt);
        }
    }

    private void avanzarTiempo(double dt) {
        if (configuracion.getTipo() != TipoPartido.POR_TIEMPO || muerteSubita) {
            return;
        }
        tiempoRestante -= dt;
        if (tiempoRestante <= 0) {
            tiempoRestante = 0;
            if (marcador.getGoles(Lado.IZQUIERDA) == marcador.getGoles(Lado.DERECHA)) {
                muerteSubita = true;
            } else {
                estado = EstadoPartido.FINALIZADO;
            }
        }
    }

    private void verificarGol() {
        Lado anotador;
        if (balon.getX() < 0) {
            anotador = Lado.DERECHA;
        } else if (balon.getX() > campo.getAncho()) {
            anotador = Lado.IZQUIERDA;
        } else {
            return;
        }
        marcador.sumarGol(anotador);
        boolean termina = muerteSubita
                || (configuracion.getTipo() == TipoPartido.POR_GOLES
                    && marcador.getGoles(anotador) >= configuracion.getLimite());
        if (termina) {
            estado = EstadoPartido.FINALIZADO;
        } else {
            reiniciarPosiciones();
        }
    }

    private void reiniciarPosiciones() {
        jugadorIzquierdo.reiniciar(xInicial(Lado.IZQUIERDA));
        jugadorDerecho.reiniciar(xInicial(Lado.DERECHA));
        balon.reiniciar(campo.getAncho() / 2, campo.getAlto() / 2);
    }

    private double xInicial(Lado lado) {
        return lado == Lado.IZQUIERDA ? Campo.ANCHO * 0.25 : Campo.ANCHO * 0.75;
    }

    private void resolverContacto(Jugador j) {
        double dx = balon.getX() - j.getCentroX();
        double dy = balon.getY() - j.getCentroY();
        double distancia = Math.hypot(dx, dy);
        double minima = Jugador.RADIO + Balon.RADIO;
        if (distancia == 0) {
            return;
        }
        if (j.estaPateando() && distancia < minima + Jugador.ALCANCE_PATADA) {
            double sentido = j.getLado() == Lado.IZQUIERDA ? 1 : -1;
            balon.setVelocidad(sentido * Jugador.FUERZA_PATADA, Jugador.FUERZA_PATADA * 0.6);
            j.consumirPatada();
            return;
        }
        if (distancia < minima) {
            double nx = dx / distancia;
            double ny = dy / distancia;
            balon.setPosicion(j.getCentroX() + nx * minima, j.getCentroY() + ny * minima);
            double relativa = (balon.getVx() - j.getVx()) * nx + (balon.getVy() - j.getVy()) * ny;
            if (relativa < 0) {
                double impulso = -(1 + COEF_REBOTE_JUGADOR) * relativa;
                balon.setVelocidad(balon.getVx() + impulso * nx, balon.getVy() + impulso * ny);
            }
        }
    }
}
