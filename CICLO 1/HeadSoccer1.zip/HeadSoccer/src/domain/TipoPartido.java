package domain;

/** Forma en que termina un partido. */
public enum TipoPartido {
    POR_TIEMPO, POR_GOLES
}
