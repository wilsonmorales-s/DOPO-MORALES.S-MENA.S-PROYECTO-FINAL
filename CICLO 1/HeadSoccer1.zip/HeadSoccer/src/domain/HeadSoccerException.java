package domain;

/** Error de las reglas del juego (configuracion invalida, por ejemplo). */
public class HeadSoccerException extends Exception {

    public static final String LIMITE_TIEMPO = "El tiempo debe estar entre 1 y 10 minutos";
    public static final String LIMITE_GOLES = "Los goles deben estar entre 1 y 10";
    public static final String NOMBRE_VACIO = "Cada jugador debe tener un nombre";
    public static final String TIPO_NULO = "Debe elegir el tipo de partido";

    public HeadSoccerException(String mensaje) {
        super(mensaje);
    }
}
