package domain;

/** Jugador de cabeza grande. (x, y) es el centro de la base; y se mide desde el suelo. */
public class Jugador {

    public static final double RADIO = 45;
    public static final double VELOCIDAD = 320;
    public static final double VELOCIDAD_SALTO = 650;
    public static final double GRAVEDAD = 1800;
    public static final double DURACION_PATADA = 0.25;
    public static final double ALCANCE_PATADA = 30;
    public static final double FUERZA_PATADA = 750;

    private final String nombre;
    private final Lado lado;
    private double x;
    private double y;
    private double vy;
    private int direccion;
    private double tiempoPatada;

    public Jugador(String nombre, Lado lado, double x) {
        this.nombre = nombre;
        this.lado = lado;
        this.x = x;
    }

    public String getNombre() { return nombre; }
    public Lado getLado() { return lado; }
    public double getX() { return x; }
    public double getY() { return y; }
    public double getVx() { return direccion * VELOCIDAD; }
    public double getVy() { return vy; }
    public double getCentroX() { return x; }
    public double getCentroY() { return y + RADIO; }
    public boolean estaEnSuelo() { return y <= 0; }
    public boolean estaPateando() { return tiempoPatada > 0; }

    /** -1 izquierda, 0 quieto, 1 derecha. */
    public void mover(int direccion) {
        this.direccion = Integer.signum(direccion);
    }

    public void saltar() {
        if (estaEnSuelo()) {
            vy = VELOCIDAD_SALTO;
        }
    }

    public void patear() {
        if (!estaPateando()) {
            tiempoPatada = DURACION_PATADA;
        }
    }

    /** Se llama cuando la patada ya golpeo el balon. */
    public void consumirPatada() {
        tiempoPatada = 0;
    }

    public void reiniciar(double x) {
        this.x = x;
        this.y = 0;
        this.vy = 0;
        this.direccion = 0;
        this.tiempoPatada = 0;
    }

    public void actualizar(double dt, Campo campo) {
        x += direccion * VELOCIDAD * dt;
        x = Math.max(RADIO, Math.min(campo.getAncho() - RADIO, x));

        vy -= GRAVEDAD * dt;
        y += vy * dt;
        if (y <= 0) {
            y = 0;
            vy = 0;
        }
        if (tiempoPatada > 0) {
            tiempoPatada = Math.max(0, tiempoPatada - dt);
        }
    }
}
