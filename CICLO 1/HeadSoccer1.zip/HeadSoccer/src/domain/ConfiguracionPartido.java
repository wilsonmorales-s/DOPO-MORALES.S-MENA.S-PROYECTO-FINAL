package domain;

/** Opciones elegidas antes de jugar. */
public class ConfiguracionPartido {

    public static final int MIN_LIMITE = 1;
    public static final int MAX_LIMITE = 10;

    private final TipoPartido tipo;
    private final int limite;
    private final String nombreIzquierdo;
    private final String nombreDerecho;

    /** limite son minutos si el tipo es POR_TIEMPO y goles si es POR_GOLES. */
    public ConfiguracionPartido(TipoPartido tipo, int limite, String nombreIzquierdo, String nombreDerecho)
            throws HeadSoccerException {
        if (tipo == null) {
            throw new HeadSoccerException(HeadSoccerException.TIPO_NULO);
        }
        if (limite < MIN_LIMITE || limite > MAX_LIMITE) {
            throw new HeadSoccerException(tipo == TipoPartido.POR_TIEMPO
                    ? HeadSoccerException.LIMITE_TIEMPO : HeadSoccerException.LIMITE_GOLES);
        }
        if (nombreIzquierdo == null || nombreIzquierdo.isBlank()
                || nombreDerecho == null || nombreDerecho.isBlank()) {
            throw new HeadSoccerException(HeadSoccerException.NOMBRE_VACIO);
        }
        this.tipo = tipo;
        this.limite = limite;
        this.nombreIzquierdo = nombreIzquierdo.trim();
        this.nombreDerecho = nombreDerecho.trim();
    }

    public TipoPartido getTipo() { return tipo; }
    public int getLimite() { return limite; }
    public String getNombreIzquierdo() { return nombreIzquierdo; }
    public String getNombreDerecho() { return nombreDerecho; }
}
