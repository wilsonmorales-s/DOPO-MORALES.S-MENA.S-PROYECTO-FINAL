package domain;

/** Balon con gravedad y rebotes. (x, y) es el centro; y se mide desde el suelo. */
public class Balon {

    public static final double RADIO = 18;
    public static final double GRAVEDAD = 1400;
    public static final double REBOTE = 0.75;
    public static final double ROZAMIENTO_SUELO = 1.5;

    private double x;
    private double y;
    private double vx;
    private double vy;

    public Balon(double x, double y) {
        setPosicion(x, y);
    }

    public double getX() { return x; }
    public double getY() { return y; }
    public double getVx() { return vx; }
    public double getVy() { return vy; }

    public void setPosicion(double x, double y) {
        this.x = x;
        this.y = y;
    }

    public void setVelocidad(double vx, double vy) {
        this.vx = vx;
        this.vy = vy;
    }

    /** Deja el balon quieto en el punto indicado. */
    public void reiniciar(double x, double y) {
        setPosicion(x, y);
        setVelocidad(0, 0);
    }

    /** Avanza dt segundos. */
    public void actualizar(double dt, Campo campo) {
        vy -= GRAVEDAD * dt;
        x += vx * dt;
        y += vy * dt;

        if (y - RADIO < 0) {
            y = RADIO;
            if (vy < 0) {
                vy = -vy * REBOTE;
            }
            if (Math.abs(vy) < 40) {
                vy = 0;
            }
            vx *= Math.max(0, 1 - ROZAMIENTO_SUELO * dt);
        }
        if (y + RADIO > campo.getAlto()) {
            y = campo.getAlto() - RADIO;
            if (vy > 0) {
                vy = -vy * REBOTE;
            }
        }
        if (!campo.cabeEnPorteria(y, RADIO)) {
            if (x - RADIO < 0) {
                x = RADIO;
                vx = Math.abs(vx) * REBOTE;
            } else if (x + RADIO > campo.getAncho()) {
                x = campo.getAncho() - RADIO;
                vx = -Math.abs(vx) * REBOTE;
            }
        }
    }
}
