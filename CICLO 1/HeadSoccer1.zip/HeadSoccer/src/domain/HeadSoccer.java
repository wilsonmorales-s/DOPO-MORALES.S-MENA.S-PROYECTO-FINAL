package domain;

/**
 * Punto de entrada al dominio. La capa de presentacion solo habla con esta clase
 * y lee el estado del partido a traves de getPartido().
 */
public class HeadSoccer {

    private Partido partido;

    public void iniciarPartido(ConfiguracionPartido configuracion) throws HeadSoccerException {
        if (configuracion == null) {
            throw new HeadSoccerException(HeadSoccerException.TIPO_NULO);
        }
        partido = new Partido(configuracion);
    }

    public boolean hayPartido() {
        return partido != null;
    }

    public Partido getPartido() {
        return partido;
    }

    /** Las acciones siguientes no hacen nada si todavia no hay partido. */
    public void actualizar(double dt) {
        if (partido != null) {
            partido.actualizar(dt);
        }
    }

    public void moverJugador(Lado lado, int direccion) {
        if (partido != null) {
            partido.getJugador(lado).mover(direccion);
        }
    }

    public void saltar(Lado lado) {
        if (partido != null) {
            partido.getJugador(lado).saltar();
        }
    }

    public void patear(Lado lado) {
        if (partido != null) {
            partido.getJugador(lado).patear();
        }
    }

    public void pausar() {
        if (partido != null) {
            partido.pausar();
        }
    }

    public void reanudar() {
        if (partido != null) {
            partido.reanudar();
        }
    }

    public void terminar() {
        if (partido != null) {
            partido.terminar();
        }
    }
}
