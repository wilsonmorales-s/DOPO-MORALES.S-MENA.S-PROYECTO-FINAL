package domain;

/** Goles de cada lado. */
public class Marcador {

    private int golesIzquierda;
    private int golesDerecha;

    public void sumarGol(Lado lado) {
        if (lado == Lado.IZQUIERDA) {
            golesIzquierda++;
        } else {
            golesDerecha++;
        }
    }

    public int getGoles(Lado lado) {
        return lado == Lado.IZQUIERDA ? golesIzquierda : golesDerecha;
    }

    public void reiniciar() {
        golesIzquierda = 0;
        golesDerecha = 0;
    }
}
