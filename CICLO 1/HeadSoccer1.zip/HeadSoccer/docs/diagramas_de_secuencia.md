# Diagramas de secuencia - Head Soccer (Versión uno)

Tres escenarios del Jugador vs Jugador. Los nombres coinciden con las clases y métodos del código.

## 1. Configurar e iniciar un partido

```mermaid
sequenceDiagram
    actor Usuario
    participant PanelConfiguracion
    participant HeadSoccerGUI
    participant ConfiguracionPartido
    participant HeadSoccer
    participant Partido
    participant PanelJuego

    Usuario->>PanelConfiguracion: elige tipo, límite y nombres, pulsa COMENZAR
    PanelConfiguracion->>ConfiguracionPartido: new ConfiguracionPartido(tipo, limite, nombre1, nombre2)
    alt datos inválidos
        ConfiguracionPartido-->>PanelConfiguracion: HeadSoccerException
        PanelConfiguracion-->>Usuario: muestra el mensaje de error
    else datos válidos
        ConfiguracionPartido-->>PanelConfiguracion: configuracion
        PanelConfiguracion->>HeadSoccerGUI: comenzar(configuracion)
        HeadSoccerGUI->>HeadSoccer: iniciarPartido(configuracion)
        HeadSoccer->>Partido: new Partido(configuracion)
        Partido-->>HeadSoccer: partido EN_JUEGO
        HeadSoccerGUI->>PanelJuego: iniciar()
        PanelJuego-->>Usuario: muestra la cancha y arranca el reloj
    end
```

## 2. Un cuadro de juego: mover, saltar y patear

```mermaid
sequenceDiagram
    actor Usuario
    participant PanelJuego
    participant HeadSoccer
    participant Partido
    participant Jugador
    participant Balon

    Usuario->>PanelJuego: mantiene D y pulsa S
    PanelJuego->>HeadSoccer: moverJugador(IZQUIERDA, 1)
    HeadSoccer->>Jugador: mover(1)
    PanelJuego->>HeadSoccer: patear(IZQUIERDA)
    HeadSoccer->>Jugador: patear()

    loop cada 16 ms (Timer)
        PanelJuego->>HeadSoccer: actualizar(dt)
        HeadSoccer->>Partido: actualizar(dt)
        Partido->>Jugador: actualizar(dt, campo)
        Partido->>Partido: resolverContacto(jugador)
        opt el balón está al alcance y el jugador patea
            Partido->>Jugador: estaPateando()
            Partido->>Balon: setVelocidad(vx, vy)
            Partido->>Jugador: consumirPatada()
        end
        Partido->>Balon: actualizar(dt, campo)
        Partido->>Partido: verificarGol()
        Partido->>Partido: avanzarTiempo(dt)
        PanelJuego->>PanelJuego: repaint()
    end
```

## 3. Gol y fin del partido

```mermaid
sequenceDiagram
    participant PanelJuego
    participant HeadSoccer
    participant Partido
    participant Balon
    participant Marcador
    participant Jugador

    PanelJuego->>HeadSoccer: actualizar(dt)
    HeadSoccer->>Partido: actualizar(dt)
    Partido->>Balon: actualizar(dt, campo)
    Partido->>Partido: verificarGol()
    Partido->>Balon: getX()
    Balon-->>Partido: x fuera de la cancha
    Partido->>Marcador: sumarGol(lado)

    alt muerte súbita o se llegó a la meta de goles
        Partido->>Partido: estado = FINALIZADO
        PanelJuego->>Partido: getGanador()
        Partido-->>PanelJuego: jugador con más goles
        PanelJuego-->>PanelJuego: dibuja GANA nombre
    else el partido sigue
        Partido->>Jugador: reiniciar(xInicial)
        Partido->>Balon: reiniciar(centro)
    end

    Partido->>Partido: avanzarTiempo(dt)
    opt tipo POR_TIEMPO y tiempo agotado
        alt marcador empatado
            Partido->>Partido: muerteSubita = true
        else hay ganador
            Partido->>Partido: estado = FINALIZADO
        end
    end
```
