# Head Soccer - Versión uno (Presentación + Dominio)

Jugador vs Jugador, nivel básico. Java 21, Swing y JUnit 5.

- `src/domain`: lógica del juego, sin dependencias de Swing. Punto de entrada: `HeadSoccer`.
- `src/presentation`: interfaz. Clase principal: `HeadSoccerGUI`.
- `test/domain`: pruebas de unidad (47).
- `docs/diagramas_de_secuencia.md`: diagramas de secuencia en Mermaid.

## Compilar y ejecutar

```
javac -encoding UTF-8 -d out $(find src -name '*.java')
java -cp out presentation.HeadSoccerGUI
```

En Eclipse o VS Code basta con ejecutar `presentation.HeadSoccerGUI`.

## Pruebas

```
javac -encoding UTF-8 -cp lib/junit-platform-console-standalone-1.14.4.jar -d out $(find src test -name '*.java')
java -jar lib/junit-platform-console-standalone-1.14.4.jar execute --class-path out --scan-class-path
```

## Controles

| Acción | Jugador 1 (izquierda) | Jugador 2 (derecha) |
|---|---|---|
| Mover | A / D | Flechas izquierda / derecha |
| Saltar | W | Flecha arriba |
| Patear | S | Flecha abajo |

Pausa: ESC o P. Terminar: T. Menú: M. Revancha al terminar: R o Enter.
